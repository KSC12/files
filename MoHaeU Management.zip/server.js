const express = require("express");
const path = require("path");
const multer = require('multer');
const fs = require('fs');

const app = express();

const port = 8000;

// Set EJS as the view engine
app.set("view engine", "ejs");

// Set the views directory
app.set("views", path.join(__dirname, "views"));

// 정적 파일 제공
app.use(express.static('public'));

// 파일 업로드를 위한 설정
const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

// 파일 업로드 엔드포인트
app.post('/upload', upload.single('file'), (req, res) => {
    res.status(200).send('File uploaded successfully.');
});

// 파일 다운로드 엔드포인트
app.get('/download/:filename', (req, res) => {
    const fileName = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', fileName);

    // 파일 존재 여부 확인 후 다운로드
    if (fs.existsSync(filePath)) {
        res.download(filePath);
    } else {
        res.status(404).send('File not found.');
    }
});

// 파일 목록 조회 엔드포인트
app.get('/files', (req, res) => {
    const files = fs.readdirSync(path.join(__dirname, 'uploads'));
    res.json(files);
});

app.listen(port, () => {
    console.log("서버가 정상적으로 실행되었습니다.");
});

// Define a route for the root ("/") URL
app.get("/", (request, response) => {
    // Render the main.ejs file
    response.render("main");
});

app.get("/file", (request, response) => {
    // Render the main.ejs file
    response.render("file");
});